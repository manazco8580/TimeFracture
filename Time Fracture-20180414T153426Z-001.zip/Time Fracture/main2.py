from gamelib import *
from music import *

game=Game(1480,820,"Time Fracture")

#Graphics
titlescreen=Image("titlescreen.jpg",game)
title=Image("title.png",game)
companyname=Image("companyname.png",game)
blackbackground=Image("blackbackground.jpg",game)
back=Image("back.png",game)
citybackground=Image("citybackground.png",game)
start=Image("start.png",game)
play=Image("play.png",game)
story=Image("story.png",game)
howtoplay=Image("howtoplay.png",game)
wjwalk=Animation("williamjacksonwalk.png",10,game,507/10,74,4,use_alpha=False)
wjjump=Image("williamjacksonjump2.png",game,use_alpha=False)
begin=Image("begin.png",game)
loading=Image("loading.png",game)
loadingsymbol=Animation("loadingsymbol.png",17,game,1700/17,100,4,use_alpha=False)
pause=Image("pause.png",game)
unpause=Image("unpause.png",game)
mute=Image("mute.png",game)
unmute=Image("unmute.png",game)
level1=Image("level1.png",game)
level2=Image("Level-2.png",game)
font=Font(green,15,green,"Lucida Console")
tip1=Image("tip1.png",game)
tip2=Image("tip2.png",game)
tip3=Image("Tip-You-Have-Powers.png",game)
tip4=Image("But-Use-Them-When-Necessary.png",game)
floorspikes=Image("floorspikes.png",game,use_alpha=False)
gameover=Image("gameover.jpg",game)
end=Image("end.png",game)
moveon=Image("Continue-To-Next-Level.png",game)
bullet=Image("bullet2.png",game)
end=Image("end.png",game)
moveon=Image("Continue-To-Next-Level.png",game)
enemy=Animation("enemywalk.png",2,game,159/2,79,32,use_alpha=False)
enemy1=Animation("enemywalk.png",2,game,159/2,79,32,use_alpha=False)
enemy2=Animation("enemywalk.png",2,game,159/2,79,32,use_alpha=False)

game.setBackground(citybackground)
citybackground.resizeTo(1480,820)
blackbackground.resizeTo(1480,820)
titlescreen.resizeTo(1480,820)
gameover.resizeTo(1480,820)

blackbackground.visible=False
title.y-=250
companyname.resizeBy(-50)
companyname.y+=380
start.y+=220
start.resizeBy(-50)
play.resizeBy(-25)
play.y-=50
story.resizeBy(-25)
story.y+=50
howtoplay.resizeBy(-20)
howtoplay.y+=150
back.resizeBy(-45)
back.moveTo(65,25)
back.visible=False
wjwalk.resizeBy(40)
wjwalk.y+=245
wjjump.resizeBy(40)
wjjump.y+=245
wjjump.visible=False
begin.resizeBy(-25)
begin.y+=340
begin.visible=False
loading.resizeBy(-25)
loading.y+=340
loadingsymbol.resizeBy(-35)
loadingsymbol.y+=370
loadingsymbol.x+=710
pause.resizeBy(-65)
pause.y-=380
pause.x-=550
mute.resizeBy(-65)
mute.y-=380
mute.x+=500
unmute.resizeBy(-65)
unmute.y-=340
unmute.x+=500
level1.resizeBy(-15)
level1.y-=370
level2.resizeBy(-15)
level2.y-=370
tip1.resizeBy(-25)
tip2.resizeBy(-25)
tip2.y+=60
tip3.resizeBy(-25)
tip4.resizeBy(-25)
tip4.y+=60
floorspikes.resizeBy(-70)
floorspikes.moveTo(game.width,675)
floorspikes.setSpeed(4,90)
end.y+=200
end.resizeBy(-35)
moveon.resizeBy(-25)
bullet.resizeBy(-85)
bullet.visible=False
#Health Packs
healthpacks=[]
for index in range(10):
    healthpacks.append(Image("healthpack.png",game,use_alpha = False))

for index in range(10):
    x=randint(100,1300)
    z=randint(1,3)
    healthpacks[index].moveTo(x,-950)
    healthpacks[index].setSpeed(z,180)
    healthpacks[index].resizeBy(-80)

healthpacks1=[]
for index in range(10):
    healthpacks1.append(Image("healthpack.png",game,use_alpha = False))

for index in range(10):
    x=randint(100,1300)
    z=randint(1,3)
    healthpacks1[index].moveTo(x,-1450)
    healthpacks1[index].setSpeed(z,180)
    healthpacks1[index].resizeBy(-80)

healthpacks2=[]
for index in range(10):
    healthpacks2.append(Image("healthpack.png",game,use_alpha = False))

for index in range(10):
    x=randint(100,1300)
    z=randint(1,3)
    healthpacks2[index].moveTo(x,-1680)
    healthpacks2[index].setSpeed(z,180)
    healthpacks2[index].resizeBy(-80)


#Power Packs
powerpacks=[]
for index in range(10):
    powerpacks.append(Animation("magic_001.png",30,game,960/5,1152/6,4,use_alpha=False))

for index in range(10):
    x=randint(250,1300)
    z=randint(1,3)
    powerpacks[index].moveTo(x,-950)
    powerpacks[index].setSpeed(z,180)
    powerpacks[index].resizeBy(-80)

powerpacks1=[]
for index in range(10):
    powerpacks1.append(Animation("magic_001.png",30,game,960/5,1152/6,4,use_alpha=False))

for index in range(10):
    x=randint(250,1300)
    z=randint(1,3)
    powerpacks1[index].moveTo(x,-1450)
    powerpacks1[index].setSpeed(z,180)
    powerpacks1[index].resizeBy(-80)

powerpacks2=[]
for index in range(10):
    powerpacks2.append(Animation("magic_001.png",30,game,960/5,1152/6,4,use_alpha=False))

for index in range(10):
    x=randint(250,1300)
    z=randint(1,3)
    powerpacks2[index].moveTo(x,-1680)
    powerpacks2[index].setSpeed(z,180)
    powerpacks2[index].resizeBy(-80)


#Sounds


#Startup Screen
meunMusic()
playmeunMusic()

while not game.over:
    game.processInput()
    
    titlescreen.draw()
    title.draw()
    companyname.draw()
    start.draw()
    
    if start.collidedWith(mouse) and mouse.LeftClick:
        game.over=True
            
    game.update(151)
    
game.over=False

#Main Meun
while not game.over:
    game.processInput()

    titlescreen.draw()
    play.draw()
    story.draw()
    howtoplay.draw()
    blackbackground.draw()
    back.draw()
    
    if play.collidedWith(mouse) and mouse.LeftClick:
        stopmeunMusic()
        game.over=True

    if back.collidedWith(mouse) and mouse.LeftClick:
        blackbackground.visible=False
        back.visible=False
        play.visible=True
        story.visible=True
        howtoplay.visible=True

    if story.collidedWith(mouse) and mouse.LeftClick:
        blackbackground.visible=True
        back.visible=True
        play.visible=False
        story.visible=False
        howtoplay.visible=False

    if howtoplay.collidedWith(mouse) and mouse.LeftClick:
        blackbackground.visible=True
        back.visible=True
        play.visible=False
        story.visible=False
        howtoplay.visible=False

    game.update(151)
    
game.over=False

#Loading Screen
loadingMusic()
playloadingMusic()

time=601

while not game.over:
    game.processInput()

    blackbackground.draw()
    blackbackground.visible=True
    begin.draw()
    loading.draw()
    loadingsymbol.draw()
    level1.draw()
    tip1.draw()
    tip2.draw()

    if time>0:
        game.update(101)
        time-=1
        print(time)
        continue

    if time<2:
        begin.visible=True
        loading.visible=False
        loadingsymbol.visible=False
    
    if begin.collidedWith(mouse) and mouse.LeftClick:
        stoploadingMusic()
        game.over=True

    game.update(151)
game.over=False

#Level 1
game.over=True
gameMusic()
playgameMusic()

time=3250
powerlevel=0
jumpboost=100

while not game.over:
    game.processInput()
    
    citybackground.move()
    game.scrollBackground("left",3.5)
    pause.draw()
    wjwalk.move()
    wjjump.move()
    wjjump.moveTo(wjwalk.x,wjwalk.y)
    mute.draw()
    unmute.draw()
    level1.draw()
    floorspikes.move()

    for index in range(10):
        healthpacks[index].move()

        if healthpacks[index].collidedWith(wjwalk,"rectangle"):
            wjwalk.health+=15
            healthpacks[index].visible=False

        if healthpacks[index].collidedWith(wjjump,"rectangle"):
            wjwalk.health+=15
            healthpacks[index].visible=False

        if healthpacks[index].y>700:
            healthpacks[index].visible=False

    for index in range(10):
        healthpacks1[index].move()

        if healthpacks1[index].collidedWith(wjwalk,"rectangle"):
            wjwalk.health+=15
            healthpacks1[index].visible=False

        if healthpacks1[index].collidedWith(wjjump,"rectangle"):
            wjwalk.health+=15
            healthpacks1[index].visible=False

        if healthpacks1[index].y>700:
            healthpacks1[index].visible=False

    for index in range(10):
        healthpacks2[index].move()

        if healthpacks2[index].collidedWith(wjwalk,"rectangle"):
            wjwalk.health+=15
            healthpacks2[index].visible=False

        if healthpacks2[index].collidedWith(wjjump,"rectangle"):
            wjwalk.health+=15
            healthpacks2[index].visible=False

        if healthpacks2[index].y>700:
            healthpacks2[index].visible=False
            
    for index in range(10):
        powerpacks[index].move()

        if powerpacks[index].collidedWith(wjwalk,"rectangle"):
            powerlevel+=20
            powerpacks[index].visible=False

        if powerpacks[index].collidedWith(wjjump,"rectangle"):
            powerlevel+=20
            powerpacks[index].visible=False

        if powerpacks[index].y>700:
            powerpacks[index].visible=False

    for index in range(10):
        powerpacks1[index].move()

        if powerpacks1[index].collidedWith(wjwalk,"rectangle"):
            powerlevel+=20
            powerpacks1[index].visible=False

        if powerpacks1[index].collidedWith(wjjump,"rectangle"):
            powerlevel+=20
            powerpacks1[index].visible=False

        if powerpacks1[index].y>700:
            powerpacks1[index].visible=False

    for index in range(10):
        powerpacks2[index].move()

        if powerpacks2[index].collidedWith(wjwalk,"rectangle"):
            powerlevel+=20
            powerpacks2[index].visible=False

        if powerpacks2[index].collidedWith(wjjump,"rectangle"):
            powerlevel+=20
            powerpacks2[index].visible=False

        if powerpacks2[index].y>700:
            powerpacks2[index].visible=False

    if floorspikes.isOffScreen("left"):
        x=randint(1500,1600)
        floorspikes.moveTo(x,675)

    if floorspikes.collidedWith(wjwalk):
        wjwalk.health-=5

    if floorspikes.collidedWith(wjjump):
        wjwalk.health-=5
        
    #Controls
    if wjwalk.y<665 or wjjump.y<665:
        wjwalk.y+=4
        wjjump.y+=4
    
    if keys.Pressed[K_w]:
        wjwalk.x+=3.77
    elif keys.Pressed[K_w]:
        wjwalk.x-=3.77

    if not keys.Pressed[K_w]:
        wjwalk.x-=1

    if keys.Pressed[K_s]:
        wjwalk.x-=3.77
    
    if keys.Pressed[K_SPACE]:
        wjwalk.visible=False
        wjjump.visible=True
        wjwalk.y-=7.2
        wjjump.y-=7.2
        jumpboost-=1
        
    if jumpboost<0:
        wjwalk.y+=4
        wjjump.y+=4
        jumpboost+=1

    if jumpboost<100 and not keys.Pressed[K_SPACE]:
        jumpboost+=1
        
    if jumpboost>100:
        jumpboost-=1
        jumpboost+=1
        
    if not keys.Pressed[K_SPACE]:
        wjwalk.visible=True
        wjjump.visible=False

    if keys.Pressed[K_ESCAPE]:
        unpause.draw()
        game.update(101)
        game.wait(K_TAB)

    if keys.Pressed[K_n]:
        stopgameMusic()

    if keys.Pressed[K_m]:
        playgameMusic()

    game.drawText("Your Health:"+str(wjwalk.health),5,65,font)
    game.drawText("Your Power Level:"+str(powerlevel),5,85,font)
    game.drawText("Your Jump Boost Fuel:"+str(jumpboost),5,105,font)
    
    #Game Over
    if wjwalk.health<0:
        stopgameMusic()
        gameover.draw()
        end.draw()
        game.update(151)
        game.wait(K_RETURN)
        game.quit()

    if time>0:
        game.update(101)
        time-=1
        print(time)
        continue

    if time<1:
        moveon.draw()
        floorspikes.visible=False

    if moveon.collidedWith(mouse) and mouse.LeftClick:
        game.over=True
    
    game.update(151)
game.over=False

#Loading Screen2
loadingMusic()
playloadingMusic()

time=601

while not game.over:
    game.processInput()

    blackbackground.draw()
    blackbackground.visible=True
    begin.draw()
    loading.draw()
    loadingsymbol.draw()
    level2.draw()
    tip3.draw()
    tip4.draw()

    if time>0:
        game.update(101)
        time-=1
        print(time)
        continue

    if time<2:
        begin.visible=True
        loading.visible=False
        loadingsymbol.visible=False
    
    if begin.collidedWith(mouse) and mouse.LeftClick:
        stoploadingMusic()
        game.over=True

    game.update(151)
game.over=False

#Level 2
game.over=False
gameMusic()
playgameMusic()

jumpboost=100

while not game.over:
    game.processInput()
    
    citybackground.move()
    game.scrollBackground("left",3.5)
    pause.draw()
    wjwalk.move()
    wjjump.move()
    wjjump.moveTo(wjwalk.x,wjwalk.y)
    mute.draw()
    unmute.draw()
    level2.draw()
    bullet.move()

    enemy.move()
    x=randint(1,3)
    enemy.setSpeed(x,90)

    enemy1.move()
    y=randint(2,4)
    enemy1.setSpeed(y,90)

    enemy2.move()
    enemy2.setSpeed(2,90)

    if enemy.isOffScreen("left"):
        x=randint(1500,1600)
        enemy.moveTo(x,675)

    if enemy1.isOffScreen("left"):
        x=randint(1550,1650)
        enemy1.moveTo(x,675)

    if enemy2.isOffScreen("left"):
        x=randint(1600,1700)
        enemy2.moveTo(x,675)

    #Controls
    if wjwalk.y<665 or wjjump.y<665:
        wjwalk.y+=4
        wjjump.y+=4
    
    if keys.Pressed[K_w]:
        wjwalk.x+=3.77
    elif keys.Pressed[K_w]:
        wjwalk.x-=3.77

    if not keys.Pressed[K_w]:
        wjwalk.x-=1

    if keys.Pressed[K_s]:
        wjwalk.x-=3.77
    
    if keys.Pressed[K_SPACE]:
        wjwalk.visible=False
        wjjump.visible=True
        wjwalk.y-=7.2
        wjjump.y-=7.2
        jumpboost-=1
        
    if jumpboost<0:
        wjwalk.y+=4
        wjjump.y+=4
        jumpboost+=1

    if jumpboost<100 and not keys.Pressed[K_SPACE]:
        jumpboost+=1
        
    if jumpboost>100:
        jumpboost-=1
        jumpboost+=1
        
    if not keys.Pressed[K_SPACE]:
        wjwalk.visible=True
        wjjump.visible=False

    if keys.Pressed[K_ESCAPE]:
        unpause.draw()
        game.update(101)
        game.wait(K_TAB)

    if keys.Pressed[K_n]:
        stopgameMusic()

    if keys.Pressed[K_m]:
        playgameMusic()

    if keys.Pressed[K_LSHIFT]:
        bullet.moveTo(wjwalk.x,wjwalk.y)
        bullet.setSpeed(6,-90)
        bullet.visible = True

    if bullet.collidedWith(enemywalk):
        enemywalk.damage += 25
        bullet.visible = False

    if bullet.collidedWith(enemywalk):
        bullet.visible = False
        enemywalk.visible = False

    game.drawText("Your Health:"+str(wjwalk.health),5,65,font)
    game.drawText("Your Power Level:"+str(powerlevel),5,85,font)
    game.drawText("Your Jump Boost Fuel:"+str(jumpboost),5,105,font)

    #Game Over
    if wjwalk.health<0:
        stopgameMusic()
        gameover.draw()
        end.draw()
        game.update(151)
        game.wait(K_RETURN)
        game.quit()

    game.update(151)
game.over=False
    

game.quit()
