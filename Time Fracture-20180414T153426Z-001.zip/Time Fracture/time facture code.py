from gamelib import*

game = Game(1480,820,"Time Facture")

forcefield = Animation("forcefield.png",20,game,960/5,768/4)
forcefield.resizeBy(25) 

wjwalk = Animation("williamjacksonwalkc.png",10,game,507/10,74)
wjwalk.resizeBy(100)
wjwalk.stop()

fullhealthbar = Image("fullhealthbar.png",game)
fullhealthbar.resizeBy(-80)
fullhealthbar.moveTo(wjwalk.x,wjwalk.y+20)

citybackground = Image("citybackground.png",game)
citybackground.resizeTo(1480,820)
game.setBackground(citybackground)

enemy = Animation("enemy2.png",8,game,246/8,46,4)
enemy.resizeBy(150)

enemyjp = Animation("enjump.png",6,game,217/6,44,4,use_alpha=False)
enemyjp.resizeBy(150)

bullet = Image("bullet2.png",game)
bullet.resizeBy(-75)

#Title Screen
while not game.over:
    game.processInput()

    game.scrollBackground("left",1.7)
    citybackground.draw()
    #enemyjp.draw()
    enemy.draw()
    #wjwalk.draw()
    #fullhealthbar.draw()
    forcefield.draw()
    
    if wjwalk.y < 500:
        wjwalk.y += 4 #Gravity!

    if keys.Pressed[K_RIGHT]:
            wjwalk.nextFrame() 
            wjwalk.x += 5

    elif keys.Pressed[K_RIGHT]:
            wjwalk.x -= 5
        
    if keys.Pressed[K_LEFT]:
            wjwalk.prevFrame()
            wjwalk.x -= 3
            bullet.visible = False
            

    elif keys.Pressed[K_LEFT]:
            wjwalk.x += 3

    if keys.Pressed[K_SPACE]:
            wjwalk.y -= 8
            

    if keys.Pressed[K_LSHIFT]:
        bullet.draw()
        bullet.x += 4

    #game.drawText("Health:"+str(wjwalk.health),wjwalk.x-30,wjwalk.y-75)



    game.update(30)
game.quit()
