from gamelib import *

def meunMusic():
    pygame.mixer.music.load("WastelandOverdriveLooped(1).mp3")

def playmeunMusic():
    pygame.mixer.music.play(-1,0.0)

def stopmeunMusic():
    pygame.mixer.music.stop()

def loadingMusic():
    pygame.mixer.music.load("loadingmusic.mp3")

def playloadingMusic():
    pygame.mixer.music.play(-1,0.0)

def stoploadingMusic():
    pygame.mixer.music.stop()

def gameMusic():
    pygame.mixer.music.load("TacticalPursuit.mp3")

def playgameMusic():
    pygame.mixer.music.play(-1,0.0)

def stopgameMusic():
    pygame.mixer.music.stop()
