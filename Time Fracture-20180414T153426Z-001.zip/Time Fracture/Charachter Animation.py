from gamelib import *

game = Game(800,800,"Walking Animation")
blob = Animation("Blob_Walk.png",24,game,558/6,632/4)
blob.stop()

ground = Image("platform.png",game,False)
ground.resizeTo(game.width,ground.height)
ground.y = game.height - 50

rock = Image("rock.png",game,False)
rock.resizeBy(-30)
rock.moveTo(ground.x + 100, 650)


while not game.over:
    game.processInput()
    game.clearBackground()
    ground.draw()
    rock.draw()
    blob.draw()

    #if not blob.collidedWith(ground,"rectangle"):
    if blob.y < 500 and blob.bottom < rock.top - 10:
        blob.y += 2 #Gravity!
    
    if keys.Pressed[K_RIGHT] and not blob.collidedWith(rock):
        blob.nextFrame() 
        blob.x += 2
    elif keys.Pressed[K_RIGHT] and not blob.collidedWith(rock):
        blob.x -= 2
        
    if keys.Pressed[K_LEFT] and not blob.collidedWith(rock):
        blob.prevFrame()
        blob.x -= 2
    elif keys.Pressed[K_RIGHT] and not blob.collidedWith(rock):
        blob.x += 2

    if keys.Pressed[K_SPACE]:
        blob.y -= 6
        

    game.update(30)
game.quit()
    
